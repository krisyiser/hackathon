<?php
class Gemini
{
    private $api_key = '';
    private $base_url = 'https://generativelanguage.googleapis.com';
    
    // Modelos de Gemini
    // private $model = 'gemini-2.5-flash';
    private $model = 'gemini-2.5-flash-lite';
    // private $model = 'gemini-2.5-pro';
    // private $model = 'gemini-3-pro-preview';

    public function peticion_gemini($prompt, $schema, $archivos = []) {
        $url = "{$this->base_url}/v1beta/models/{$this->model}:generateContent?key={$this->api_key}";
    
        //CARGAMOS EL ESQUEMA
        $schema_array = null; // Inicializamos
        $rutas = ["../schemas/{$schema}.json", "schemas/{$schema}.json"];

        
        foreach ($rutas as $r) {
            if (file_exists($r)) {
                // Leemos el texto y lo convertimos a Array de PHP
                $contenido = file_get_contents($r);
                $schema_array = json_decode($contenido, true);
                break;
            }
        }
    
        // Si no encontró esquema, lanzamos error o usamos array vacío, tú decides
        if (!$schema_array) {
            // Fallback o error
            $schema_array = ["type" => "object", "properties" => []]; 
        }
    
        $parts = [["text" => $prompt]];
    
        if (!empty($archivos)) {
            
        }
    
        // CONFIGURACIÓN
        $payload = [
            "contents" => [[ "parts" => $parts ]],
            "generationConfig" => [
                "response_mime_type" => "application/json",
                // Contestar con json
                "response_schema" => $schema_array 
            ]
        ];
    
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 600); 
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    
        // Al hacer json_encode aquí, $schema_array se vuelve parte natural del JSON
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    
        $res = curl_exec($ch);
        
        if (curl_errno($ch)) throw new Exception("Error cURL: " . curl_error($ch));
        curl_close($ch);
        
        $json = json_decode($res, true);
        
        if (isset($json['error'])) {
            // Tip: A veces el error es porque el schema es inválido para la API strict
            throw new Exception("API Error ({$this->model}): " . $json['error']['message']);
        }
    
        $texto = $json['candidates'][0]['content']['parts'][0]["text"] ?? "{}";
        
        $usage = $json['usageMetadata'] ?? [];
    
        $entrada = $usage['promptTokenCount'] ?? 0;
        $salida_visible = $usage['candidatesTokenCount'] ?? 0;
        $pensamiento = $usage['thoughtsTokenCount'] ?? 0;
        $tool_use = $usage['toolUsePromptTokenCount'] ?? 0;

        return [
            "respuesta" => preg_replace('/^```json\s*|\s*```$/', '', $texto),
            "entrada" => $entrada,
            "salida" => $salida_visible,
            "pensamiento" => $pensamiento,
            "salida_cobrable" => $salida_visible + $pensamiento,
            "tool_use" => $tool_use,
            "total" => $usage['totalTokenCount'] ?? ($entrada + $salida_visible + $pensamiento + $tool_use)
        ];
    }
}
?>