<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', '/var/log/php_errors.log');
error_reporting(E_ALL);
date_default_timezone_set('America/Mexico_City');

require_once("conexion.php");

class Acciones
{
    public function checar_sesion(){
        return "success";
        
        if(isset($_SESSION["id_sesion"])){
            $id=$_SESSION["id_empresa"];
            $id_sesion=$_SESSION["id_sesion"];
            $usuario=$_SESSION["usuario"];

            $conexion = new Conexion();
            $conexion = $conexion->conectar_zignus();
            
            $sql="SELECT id FROM empresas WHERE id=:id AND id_sesion=:id_sesion";
            $consulta = $conexion->prepare($sql);
            $consulta->bindParam(":id", $id);
            $consulta->bindParam(":id_sesion", $id_sesion);

            if($consulta->execute()){
                $filas=$consulta->rowCount();
    
                if($filas!=0)
                {
                    return "success";
                }
                else
                {
                    return "no_existe";
                }   
            }
            else{
                return $consulta->errorInfo();
            }
        }
        else{
            return "error_sesion";
        }
    }

    public function login($usuario, $password){
        // Asegura sesión activa y rotación del ID
        if (session_status() !== PHP_SESSION_ACTIVE) {
            session_start();
        }
    
        $conexion = new Conexion();
        $conexion = $conexion->conectar_zignus();
        
        $sql = "SELECT id,password,usuario,correo,razon_social,rfc FROM empresas WHERE usuario=:usuario OR correo=:correo";
        $consulta = $conexion->prepare($sql);
        $consulta->bindParam(":usuario", $usuario);
        $consulta->bindParam(":correo", $usuario);
    
        if ($consulta->execute()) {
            if ($consulta->rowCount() !== 0) {
                $datos = $consulta->fetch(PDO::FETCH_ASSOC);
                $hashed_password = $datos["password"];
    
                if (password_verify($password, $hashed_password)) {
                    $usuario = $datos["usuario"];
                    $correo = $datos["correo"];
                    $razon_social = $datos["razon_social"];
                    $rfc = $datos["rfc"];
                    $id = $datos["id"];

                    // 🔒 Mitiga fijación de sesión
                    session_regenerate_id(true);
    
                    // 1) Tomamos el ID de sesión real de PHP
                    $php_session_id = session_id();
    
                    // 2) Generamos un identificador fuerte para id_sesion (ligado a la sesión PHP)
                    //    - Opción A (recomendada): hash de (session_id + entropía)
                    $id_sesion = hash('sha256', $php_session_id . random_bytes(32));
    
                    // (Si prefieres algo legible tipo UUID, puedes usar bin2hex(random_bytes(16)))
    
                    // 3) Guardamos control y auditoría en BD (sin cookies propias)
                    $inicio_sesion = date("Y-m-d H:i:s");
                    $sql = "UPDATE empresas 
                               SET id_sesion = :id_sesion,
                                   ultima_sesion = :ultima_sesion
                             WHERE id = :id";
                    $upd = $conexion->prepare($sql);
                    $upd->bindParam(":id_sesion", $id_sesion);
                    $upd->bindParam(":ultima_sesion", $inicio_sesion);
                    $upd->bindParam(":id", $id);
                    $upd->execute();
    
                    // 4) Variables mínimas en la sesión PHP
                    $_SESSION['id_empresa'] = $id;
                    $_SESSION['usuario'] = $usuario;
                    $_SESSION['correo'] = $correo;
                    $_SESSION['razon_social'] = $razon_social;
                    $_SESSION['rfc'] = $rfc;
                    $_SESSION['id_sesion'] = $id_sesion; // espejo en memoria para comparar si lo necesitas
    
                    return "success";
                } else {
                    return "error_password";
                }
            } else {
                return "no_existe";
            }
        } else {
            return $consulta->errorInfo();
        }
    }

    public function guardar_reporte($tipo,$titulo,$descripcion,$latitud,$longitud){
        $check_sesion=$this->checar_sesion();

        if($check_sesion=="success"){

            $obj_conexion = new Conexion();
            $conexion = $obj_conexion->conexion();
		    $fecha = date("Y-m-d H:i:s"); // Ajuste del formato y punto y coma añadido
            $estatus=1;

            $sql = "INSERT INTO reportes(titulo,descripcion,tipo,latitud,longitud,fecha,estatus)
            VALUES(:titulo,:descripcion,:tipo,:latitud,:longitud,:fecha,:estatus)";
            
            $parametros = $conexion->prepare($sql);
            
            $parametros->bindParam(":titulo", $titulo);
            $parametros->bindParam(":descripcion", $descripcion);
            $parametros->bindParam(":tipo", $tipo);
            $parametros->bindParam(":latitud", $latitud);
            $parametros->bindParam(":longitud", $longitud);
            $parametros->bindParam(":fecha", $fecha);
            $parametros->bindParam(":estatus", $estatus);
            
            if ($parametros->execute()) {
                return "success";
            } else {
                return $parametros->errorInfo();
            }
        } else{
            return "no_sesion";
        }
    }

    public function pedir_reportes($latitud, $longitud, $radio_km = 30, $limite = 50){
        $obj_conexion = new Conexion();
        $conexion = $obj_conexion->conexion();
    
        $latitud = (float)$latitud;
        $longitud = (float)$longitud;
        $radio_km = (float)$radio_km;
        $limite = (int)$limite;
    
        if($limite <= 0){
            $limite = 50;
        }
    
        $sql = "SELECT
                    tmp.fecha,
                    tmp.titulo,
                    tmp.descripcion,
                    tmp.tipo,
                    NULL AS calle,
                    NULL AS calle_colindante,
                    NULL AS direccion_objeto,
                    tmp.latitud AS lat,
                    tmp.longitud AS lng,
                    tmp.distancia_km
                FROM (
                    SELECT
                        fecha,
                        titulo,
                        descripcion,
                        tipo,
                        latitud,
                        longitud,
                        (
                            6371 * ACOS(
                                COS(RADIANS(:latitud_1)) *
                                COS(RADIANS(latitud)) *
                                COS(RADIANS(longitud) - RADIANS(:longitud_1)) +
                                SIN(RADIANS(:latitud_2)) *
                                SIN(RADIANS(latitud))
                            )
                        ) AS distancia_km
                    FROM reportes
                    WHERE estatus = 1
                    AND latitud IS NOT NULL
                    AND longitud IS NOT NULL
                ) AS tmp
                WHERE tmp.distancia_km <= :radio_km
                ORDER BY tmp.distancia_km ASC
                LIMIT $limite";
    
        $consulta = $conexion->prepare($sql);
        $consulta->bindParam(":latitud_1", $latitud);
        $consulta->bindParam(":latitud_2", $latitud);
        $consulta->bindParam(":longitud_1", $longitud);
        $consulta->bindParam(":radio_km", $radio_km);
    
        if($consulta->execute()){
            $datos = $consulta->fetchAll(PDO::FETCH_ASSOC);
            return $datos;
        }else{
            return $consulta->errorInfo();
        }
    }
}