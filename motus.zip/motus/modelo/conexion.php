<?php
	class Conexion
	{
		public function conexion()
		{

			$usuario="bd_admin";
			// $usuario="root";
			// $password="";
			// $password="root";
			$password='T8!qR3#vM7@xL2$hN6pY9bK4*Zs1?';

			$host="localhost";
			$db="motus";

			$conexion= new PDO("mysql:host=$host;dbname=$db;", $usuario, $password);
			 
			return $conexion;
		}
	}
?>