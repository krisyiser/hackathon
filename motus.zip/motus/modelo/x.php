<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', '/var/log/php_errors.log');
error_reporting(E_ALL);
date_default_timezone_set('America/Mexico_City');

Class X
{
    private $bearer_token = '';

    public function buscarHashtag($hashtag, $palabras = [])
    {
        $tweets_unicos = [];
        $usuarios_unicos = [];
        $texto_plano_final = "";

        $bloques = $this->crearBloquesConsulta($hashtag, $palabras);

        foreach ($bloques as $query) {
            $params = [
                'query' => $query,
                'max_results' => 50,
                'sort_order' => 'recency',
                'tweet.fields' => 'created_at,public_metrics,author_id,lang,id',
                'expansions' => 'author_id',
                'user.fields' => 'username,name'
            ];

            $url = 'https://api.x.com/2/tweets/search/recent?' . http_build_query($params);

            $data = $this->hacerPeticionX($url);

            if (!$data["ok"]) {
                continue;
            }

            $respuesta = $data["data"];

            if (!empty($respuesta['includes']['users'])) {
                foreach ($respuesta['includes']['users'] as $user) {
                    $usuarios_unicos[$user['id']] = $user;
                }
            }

            if (!empty($respuesta['data'])) {
                foreach ($respuesta['data'] as $tweet) {
                    $tweet_id = $tweet['id'] ?? null;

                    if ($tweet_id !== null) {
                        $tweets_unicos[$tweet_id] = $tweet;
                    }
                }
            }
        }

        if (empty($tweets_unicos)) {
            return "No se encontraron resultados.";
        }

        foreach ($tweets_unicos as $tweet) {
            $tweet_id = $tweet['id'] ?? '';
            $autor_id = $tweet['author_id'] ?? null;
            $username = isset($usuarios_unicos[$autor_id]['username']) ? $usuarios_unicos[$autor_id]['username'] : 'desconocido';

            $fecha = $tweet['created_at'] ?? 'sin_fecha';
            $texto = $tweet['text'] ?? '';
            $respuestas_usuarios = $tweet['public_metrics']['reply_count'] ?? 0;

            $texto_plano_final .= "Fecha: " . $fecha . "\n";
            $texto_plano_final .= "Usuario: @" . $username . "\n";
            $texto_plano_final .= "Texto: " . $texto . "\n";
            $texto_plano_final .= "Respuestas: " . $respuestas_usuarios . "\n";

            if ($tweet_id !== '') {
                $texto_respuestas = $this->buscarRespuestasTextoPlano($tweet_id);

                if ($texto_respuestas !== "") {
                    $texto_plano_final .= "Respuestas encontradas:\n";
                    $texto_plano_final .= $texto_respuestas;
                } else {
                    $texto_plano_final .= "Respuestas encontradas: ninguna\n";
                }
            } else {
                $texto_plano_final .= "Respuestas encontradas: ninguna\n";
            }

            $texto_plano_final .= str_repeat("-", 60) . "\n";
        }

        return trim($texto_plano_final);
    }

    private function buscarRespuestasTextoPlano($tweet_id)
    {
        $texto_respuestas = "";
        $usuarios_respuestas = [];

        $params = [
            'query' => 'in_reply_to_tweet_id:' . $tweet_id . ' lang:es -is:retweet',
            'max_results' => 50,
            'sort_order' => 'recency',
            'tweet.fields' => 'created_at,author_id,lang,id',
            'expansions' => 'author_id',
            'user.fields' => 'username,name'
        ];

        $url = 'https://api.x.com/2/tweets/search/recent?' . http_build_query($params);

        $data = $this->hacerPeticionX($url);

        if (!$data["ok"]) {
            return "";
        }

        $respuesta = $data["data"];

        if (!empty($respuesta['includes']['users'])) {
            foreach ($respuesta['includes']['users'] as $user) {
                $usuarios_respuestas[$user['id']] = $user;
            }
        }

        if (!empty($respuesta['data'])) {
            foreach ($respuesta['data'] as $reply) {
                $autor_id = $reply['author_id'] ?? null;
                $username = isset($usuarios_respuestas[$autor_id]['username']) ? $usuarios_respuestas[$autor_id]['username'] : 'desconocido';

                $fecha = $reply['created_at'] ?? 'sin_fecha';
                $texto = $reply['text'] ?? '';

                $texto_respuestas .= "  Fecha respuesta: " . $fecha . "\n";
                $texto_respuestas .= "  Usuario respuesta: @" . $username . "\n";
                $texto_respuestas .= "  Texto respuesta: " . $texto . "\n";
                $texto_respuestas .= "  " . str_repeat(".", 40) . "\n";
            }
        }

        return $texto_respuestas;
    }

    private function hacerPeticionX($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->bearer_token
        ]);

        $respuesta = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if (curl_errno($ch)) {
            curl_close($ch);
            return [
                "ok" => false,
                "data" => []
            ];
        }

        curl_close($ch);

        $data = json_decode($respuesta, true);

        if ($http_code !== 200 || !is_array($data)) {
            return [
                "ok" => false,
                "data" => []
            ];
        }

        return [
            "ok" => true,
            "data" => $data
        ];
    }

    private function crearBloquesConsulta($hashtag, $palabras = [])
    {
        $bloques = [];
        $grupo_actual = [];

        $base_inicio = '#' . $hashtag;
        $base_fin = ' lang:es -is:retweet';

        foreach ($palabras as $palabra) {
            $palabra = trim((string)$palabra);

            if ($palabra === '') {
                continue;
            }

            if (strpos($palabra, ' ') !== false) {
                $palabra = '"' . str_replace('"', '', $palabra) . '"';
            }

            $grupo_prueba = $grupo_actual;
            $grupo_prueba[] = $palabra;

            $query_prueba = $base_inicio;

            if (!empty($grupo_prueba)) {
                $query_prueba .= ' (' . implode(' OR ', $grupo_prueba) . ')';
            }

            $query_prueba .= $base_fin;

            if (mb_strlen($query_prueba, 'UTF-8') > 512) {
                if (!empty($grupo_actual)) {
                    $query_final = $base_inicio . ' (' . implode(' OR ', $grupo_actual) . ')' . $base_fin;
                    $bloques[] = $query_final;
                }

                $grupo_actual = [$palabra];
            } else {
                $grupo_actual = $grupo_prueba;
            }
        }

        if (!empty($grupo_actual)) {
            $query_final = $base_inicio . ' (' . implode(' OR ', $grupo_actual) . ')' . $base_fin;
            $bloques[] = $query_final;
        }

        if (empty($bloques)) {
            $bloques[] = $base_inicio . $base_fin;
        }

        return $bloques;
    }
}
?>