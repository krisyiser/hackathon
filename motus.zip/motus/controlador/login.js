function login(){

    const input_email=document.getElementById("input_email")
    const input_password=document.getElementById("input_password")

    let str_email=input_email.value
    let str_password=input_password.value

    const formData = new FormData()
    formData.append("email", str_email)
    formData.append("password", str_password)

    fetch("https://lookitag.com/motus/controlador/login.php", { method: "POST", body: formData })
        .then(r => r.ok ? r.text() : Promise.reject("Error en la petición"))
        .then(body => {
            if (!body.includes("error")) {
                console.log(body)
                // ok
            } else {
                // error
                console.log("!!!!!")
                console.log(body)
            }
        })
        .catch(err => console.error("Error:", err))
}