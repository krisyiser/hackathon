<?php
declare(strict_types=1);

// --- DEBUG HARDCORE (temporal) ---
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');

$origin_permitido = 'https://motuscity.netlify.app';

if (isset($_SERVER['HTTP_ORIGIN']) && $_SERVER['HTTP_ORIGIN'] === $origin_permitido) {
    header('Access-Control-Allow-Origin: ' . $origin_permitido);
    header('Vary: Origin');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Allow-Credentials: true');
}

/*
    Respuesta al preflight
*/
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

header("Content-Type: text/plain; charset=UTF-8");

$api_key = "AIzaSyDPlGCi77Xm7cH7BBGtvusXBhLwfcOkg4I";

$latitud  = isset($_POST["latitud"]) ? trim((string)$_POST["latitud"]) : "";
$longitud = isset($_POST["longitud"]) ? trim((string)$_POST["longitud"]) : "";

$marcadores_default = ["seguridad", "emergencia", "obstruccion", "saturacion", "entorno"];
$marcadores = $marcadores_default;

if (isset($_POST["marcadores"])) {
    if (is_array($_POST["marcadores"])) {
        $marcadores = $_POST["marcadores"];
    } else {
        $marcadores_tmp = trim((string)$_POST["marcadores"]);

        if ($marcadores_tmp !== "") {
            $json_marcadores = json_decode($marcadores_tmp, true);

            if (is_array($json_marcadores)) {
                $marcadores = $json_marcadores;
            } else {
                $marcadores = array_map("trim", explode(",", $marcadores_tmp));
            }
        }
    }
}

if ($latitud === "" || $longitud === "") {
    exit("faltan_coordenadas");
}

if (!is_numeric($latitud) || !is_numeric($longitud)) {
    exit("coordenadas_invalidas");
}

function hacerPeticionGoogle(string $url): array
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);

    $respuesta = curl_exec($ch);

    if ($respuesta === false) {
        $error = curl_error($ch);
        curl_close($ch);
        return [
            "ok" => false,
            "error" => "error_curl: " . $error
        ];
    }

    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code !== 200) {
        return [
            "ok" => false,
            "error" => "error_http: " . $http_code
        ];
    }

    $datos = json_decode($respuesta, true);

    if (!is_array($datos)) {
        return [
            "ok" => false,
            "error" => "json_invalido"
        ];
    }

    return [
        "ok" => true,
        "datos" => $datos
    ];
}

function buscarComponente(array $results, array $tipos_prioridad): string
{
    foreach ($tipos_prioridad as $tipo_buscado) {
        foreach ($results as $resultado) {
            if (!isset($resultado["address_components"]) || !is_array($resultado["address_components"])) {
                continue;
            }

            foreach ($resultado["address_components"] as $componente) {
                if (
                    isset($componente["types"]) &&
                    is_array($componente["types"]) &&
                    in_array($tipo_buscado, $componente["types"], true)
                ) {
                    $valor = trim((string)($componente["long_name"] ?? ""));
                    if ($valor !== "") {
                        return $valor;
                    }
                }
            }
        }
    }

    return "";
}

function normalizarTexto(string $texto): string
{
    $texto = mb_strtolower(trim($texto), "UTF-8");

    $reemplazos = [
        "á" => "a", "à" => "a", "ä" => "a", "â" => "a",
        "é" => "e", "è" => "e", "ë" => "e", "ê" => "e",
        "í" => "i", "ì" => "i", "ï" => "i", "î" => "i",
        "ó" => "o", "ò" => "o", "ö" => "o", "ô" => "o",
        "ú" => "u", "ù" => "u", "ü" => "u", "û" => "u",
        "ñ" => "n"
    ];

    $texto = strtr($texto, $reemplazos);
    $texto = preg_replace('/[^a-z0-9\s]/u', ' ', $texto);
    $texto = preg_replace('/\s+/', ' ', $texto);

    return trim((string)$texto);
}

function alcaldiaAHashtag(string $alcaldia): string
{
    $normalizada = normalizarTexto($alcaldia);

    $mapa = [
        "alvaro obregon" => "AlvaroObregon",
        "azcapotzalco" => "Azcapotzalco",
        "benito juarez" => "BenitoJuarez",
        "coyoacan" => "Coyoacan",
        "cuajimalpa" => "Cuajimalpa",
        "cuajimalpa de morelos" => "Cuajimalpa",
        "cuauhtemoc" => "Cuauhtemoc",
        "gustavo a madero" => "GustavoAMadero",
        "iztacalco" => "Iztacalco",
        "iztapalapa" => "Iztapalapa",
        "la magdalena contreras" => "LaMagdalenaContreras",
        "magdalena contreras" => "LaMagdalenaContreras",
        "miguel hidalgo" => "MiguelHidalgo",
        "milpa alta" => "MilpaAlta",
        "tlahuac" => "Tlahuac",
        "tlalpan" => "Tlalpan",
        "venustiano carranza" => "VenustianoCarranza",
        "xochimilco" => "Xochimilco"
    ];

    return $mapa[$normalizada] ?? "CDMX";
}

function extraerAlcaldiaDesdeFormattedAddress(string $formatted_address): string
{
    $formatted_address = trim($formatted_address);

    // Caso común CDMX:
    // Calle, colonia, zona, alcaldía, 01210 Ciudad de México, CDMX, México
    if (preg_match('/,\s*([^,]+)\s*,\s*\d{5}\s+(?:Ciudad de México|CDMX)/ui', $formatted_address, $coincidencias)) {
        return trim($coincidencias[1]);
    }

    return "";
}

function construirCalle(string $route, string $street_number): string
{
    $route = trim($route);
    $street_number = trim($street_number);

    if ($route === "") {
        return "";
    }

    // Si la calle ya trae número o "No.", no volver a concatenarlo
    if (preg_match('/\bno\.?\b/ui', $route) || preg_match('/\d/', $route)) {
        return $route;
    }

    if ($street_number !== "") {
        return $route . " No. " . $street_number;
    }

    return $route;
}

function agregarTerminoUnico(array &$resultado, array &$vistos, string $termino): void
{
    $termino = trim($termino);

    if ($termino === "") {
        return;
    }

    $clave = normalizarTexto($termino);

    if ($clave === "") {
        return;
    }

    if (!isset($vistos[$clave])) {
        $resultado[] = $termino;
        $vistos[$clave] = true;
    }
}

function expandirPalabrasClaveViales(array $palabras_base): array
{
    $mapa_relaciones = [
        "seguridad" => [
            "accidente",
            "choque",
            "colision",
            "atropellamiento",
            "riesgo vial",
            "senalizacion",
            "semaforo"
        ],
        "emergencia" => [
            "ambulancia",
            "bomberos",
            "patrulla",
            "rescate",
            "lesionados",
            "incendio",
            "urgencia"
        ],
        "obstruccion" => [
            "bloqueo",
            "obstaculo",
            "cierre vial",
            "carril cerrado",
            "manifestacion",
            "vehiculo descompuesto",
            "arbol caido",
            "metro"
        ],
        "saturacion" => [
            "trafico",
            "congestion",
            "embotellamiento",
            "fila",
            "avance lento",
            "carga vehicular",
            "saturado",
            "metro"
        ],
        "entorno" => [
            "lluvia",
            "inundacion",
            "obra",
            "escuela",
            "hospital",
            "mercado",
            "evento"
        ]
    ];

    $resultado = [];
    $vistos = [];

    foreach ($palabras_base as $palabra) {
        $palabra = trim((string)$palabra);

        if ($palabra === "") {
            continue;
        }

        agregarTerminoUnico($resultado, $vistos, $palabra);

        $palabra_normalizada = normalizarTexto($palabra);

        if (isset($mapa_relaciones[$palabra_normalizada])) {
            foreach ($mapa_relaciones[$palabra_normalizada] as $extra) {
                agregarTerminoUnico($resultado, $vistos, $extra);
            }
        }
    }

    return array_values($resultado);
}

$url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=" .
    rawurlencode($latitud . "," . $longitud) .
    "&language=es" .
    "&region=mx" .
    "&key=" . rawurlencode($api_key);

$respuesta_google = hacerPeticionGoogle($url);
// echo "respuesta_google X: \n";
// print_r($respuesta_google);


if (!$respuesta_google["ok"]) {
    exit((string)$respuesta_google["error"]);
}

$datos = $respuesta_google["datos"];

if (($datos["status"] ?? "") !== "OK") {
    echo "status_google: " . ($datos["status"] ?? "desconocido") . "\n";
    echo "error_message: " . ($datos["error_message"] ?? "sin_detalle") . "\n";
    exit;
}

$results = isset($datos["results"]) && is_array($datos["results"]) ? $datos["results"] : [];

if (!$results) {
    exit("sin_resultados");
}

$formatted_address = trim((string)($results[0]["formatted_address"] ?? ""));

// Calle
$route = buscarComponente($results, ["route"]);
$street_number = buscarComponente($results, ["street_number"]);
$calle = construirCalle($route, $street_number);

// Colonia
$colonia = buscarComponente($results, [
    "neighborhood",
    "sublocality_level_1",
    "sublocality",
    "locality"
]);

// Alcaldía: primero por components
$alcaldia = buscarComponente($results, [
    "administrative_area_level_3",
    "administrative_area_level_2"
]);

// Fallback práctico para CDMX
if ($alcaldia === "" && $formatted_address !== "") {
    $alcaldia = extraerAlcaldiaDesdeFormattedAddress($formatted_address);
}

$hashtag_alcaldia = alcaldiaAHashtag($alcaldia);

$direccion_corta = $calle;
if ($colonia !== "") {
    $direccion_corta .= ", " . $colonia;
}
if ($alcaldia !== "") {
    $direccion_corta .= ", " . $alcaldia;
}

// echo "calle: " . $calle . "\n";
// echo "colonia: " . $colonia . "\n";
// echo "alcaldia: " . $alcaldia . "\n";
// echo "hashtag_alcaldia: " . $hashtag_alcaldia . "\n";
// echo "direccion_corta: " . $direccion_corta . "\n";

// AQui quiero convertir marcadores en un arrary mas extenso
$marcadores = expandirPalabrasClaveViales($marcadores);

require_once "../modelo/x.php";

$obj_x = new X();
$respuesta_x = $obj_x->buscarHashtag($hashtag_alcaldia, $marcadores);

// echo "Respuesta X: \n";
// print_r($respuesta_x);

// exit;

if(strpos($respuesta_x,"error_") !== false){
    echo "error_x";
}
else{
    require_once "../modelo/gemini.php";

    $asistente_motus=file_get_contents("../asistentes/motus.txt");
    
    // echo "\n Asistente motus: \n";
    // print_r($asistente_motus);

    $prompt=$asistente_motus." Aqui tienes los datos: ".$respuesta_x;
    // echo "\n Prompt: \n";
    // print_r($prompt);

    $schema="motus";

    $obj_gemini = new Gemini(); 
    $respuesta_gemini = $obj_gemini->peticion_gemini($prompt, $schema);
    
    $entrada_conversacion = $respuesta_gemini["entrada"];
    $salida_conversacion = $respuesta_gemini["salida"];
    $pensamiento_conversacion = $respuesta_gemini["pensamiento"];
    $total_conversacion = $respuesta_gemini["total"];
    
    $reportes = json_decode($respuesta_gemini["respuesta"], true)["reportes"];
    $cuenta_reportes = count($reportes);
    
    for($i = 0; $i < $cuenta_reportes; $i++){
        $objeto = $reportes[$i];
    
        $fecha_objeto = $objeto["fecha"];
        $titulo_objeto = $objeto["titulo"];
        $descripcion_objeto = $objeto["descripcion"];
        $calle_objeto = $objeto["calle"];
        $calle_colindante_objeto = $objeto["calle_colindante"];
    
        $direccion_objeto = $calle_objeto . ", " . $colonia . ", " . $alcaldia;
    
        $direccion_codificada = rawurlencode($direccion_objeto);
    
        $url_geo = "https://maps.googleapis.com/maps/api/geocode/json?address={$direccion_codificada}&key={$api_key}&language=es&region=mx";
    
        $respuesta_geo = file_get_contents($url_geo);
    
        if($respuesta_geo === false){
            die("Error al consultar Geocoding");
        }
    
        $data_geo = json_decode($respuesta_geo, true);
    
        $reportes[$i]["direccion_objeto"] = $direccion_objeto;
        $reportes[$i]["lat"] = null;
        $reportes[$i]["lng"] = null;
    
        if(
            isset($data_geo["status"]) &&
            $data_geo["status"] === "OK" &&
            !empty($data_geo["results"][0]["geometry"]["location"])
        ){
            $lat = $data_geo["results"][0]["geometry"]["location"]["lat"];
            $lng = $data_geo["results"][0]["geometry"]["location"]["lng"];
    
            $reportes[$i]["lat"] = $lat;
            $reportes[$i]["lng"] = $lng;
        }
    }
    
    require_once "../modelo/acciones.php";
    
    $obj_acciones = new Acciones();
    
    $reportes_cercanos = $obj_acciones->pedir_reportes($latitud, $longitud);
    
    if(!is_array($reportes_cercanos)){
        $reportes_cercanos = [];
    }
    
    $reportes_finales = array_merge($reportes, $reportes_cercanos);
    
    echo json_encode($reportes_finales, JSON_UNESCAPED_UNICODE);
}


?>