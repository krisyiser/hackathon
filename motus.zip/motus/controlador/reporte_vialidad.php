<?php
declare(strict_types=1);

// --- DEBUG HARDCORE (temporal) ---
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');

$origin_permitido = 'https://motuscity.netlify.app';

if (isset($_SERVER['HTTP_ORIGIN']) && $_SERVER['HTTP_ORIGIN'] === $origin_permitido) {
    header('Access-Control-Allow-Origin: ' . $origin_permitido);
    header('Vary: Origin');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Allow-Credentials: true');
}

/*
    Respuesta al preflight
*/
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

header("Content-Type: text/plain; charset=UTF-8");

// $titulo  = isset($_POST["titulo"]) ? trim((string)$_POST["titulo"]) : "";
// $descripcion  = isset($_POST["descripcion"]) ? trim((string)$_POST["descripcion"]) : "";

$resumen  = isset($_POST["resumen"]) ? trim((string)$_POST["resumen"]) : "";

require_once "../modelo/gemini.php";

$asistente_resumen=file_get_contents("../asistentes/resumen.txt");

// echo "\n Asistente motus: \n";
// print_r($asistente_resumen);

$prompt=$asistente_resumen." Aqui tienes los datos: ".$resumen;
// echo "\n Prompt: \n";
// print_r($prompt);

$schema="resumen";

$obj_gemini = new Gemini(); 
$respuesta_gemini = $obj_gemini->peticion_gemini($prompt, $schema);

$entrada_conversacion = $respuesta_gemini["entrada"];
$salida_conversacion = $respuesta_gemini["salida"];
$pensamiento_conversacion = $respuesta_gemini["pensamiento"];
$total_conversacion = $respuesta_gemini["total"];

$resumen_final= $respuesta_gemini["respuesta"];

echo $resumen_final;

?>