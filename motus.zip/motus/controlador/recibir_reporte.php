<?php
declare(strict_types=1);

// --- DEBUG HARDCORE (temporal) ---
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');

$origin_permitido = 'https://motuscity.netlify.app';

if (isset($_SERVER['HTTP_ORIGIN']) && $_SERVER['HTTP_ORIGIN'] === $origin_permitido) {
    header('Access-Control-Allow-Origin: ' . $origin_permitido);
    header('Vary: Origin');
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Allow-Credentials: true');
}

/*
    Respuesta al preflight
*/
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

header("Content-Type: text/plain; charset=UTF-8");

// $titulo  = isset($_POST["titulo"]) ? trim((string)$_POST["titulo"]) : "";
// $descripcion  = isset($_POST["descripcion"]) ? trim((string)$_POST["descripcion"]) : "";

$tipo  = isset($_POST["tipo"]) ? trim((string)$_POST["tipo"]) : "";
$titulo  = isset($_POST["titulo"]) ? trim((string)$_POST["titulo"]) : "";
$descripcion  = isset($_POST["descripcion"]) ? trim((string)$_POST["descripcion"]) : "";
$latitud  = isset($_POST["latitud"]) ? trim((string)$_POST["latitud"]) : "";
$longitud = isset($_POST["longitud"]) ? trim((string)$_POST["longitud"]) : "";

echo "latitud: ".$latitud." longitud: ".$longitud;

require_once "../modelo/acciones.php";

$obj_acciones=new Acciones();

$respuesta_guardar_reporte=$obj_acciones->guardar_reporte($tipo,$titulo,$descripcion,$latitud,$longitud);
echo $respuesta_guardar_reporte;

?>