<?php

$bearer_token = 'AAAAAAAAAAAAAAAAAAAAAIhu8wEAAAAAeoL%2F05qgS0DRBaPiV3gKUQAEIew%3DYUjt7EGJbglDxxIulYLtvTwrwRYt9EJz6Fd0YE2jSzL7EELKjl';
$query = '#metrocdmx lang:es -is:retweet';

$params = [
    'query' => $query,
    'max_results' => 10,
    'sort_order' => 'recency',
    'tweet.fields' => 'created_at,public_metrics,author_id,lang',
    'expansions' => 'author_id',
    'user.fields' => 'username,name'
];

$url = 'https://api.x.com/2/tweets/search/recent?' . http_build_query($params);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $bearer_token
]);

$respuesta = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    echo 'Error cURL: ' . curl_error($ch);
    curl_close($ch);
    exit;
}

curl_close($ch);

$data = json_decode($respuesta, true);

if ($http_code !== 200) {
    echo "Error HTTP: " . $http_code . PHP_EOL;
    print_r($data);
    exit;
}

$usuarios = [];
if (!empty($data['includes']['users'])) {
    foreach ($data['includes']['users'] as $user) {
        $usuarios[$user['id']] = $user;
    }
}

if (!empty($data['data'])) {
    foreach ($data['data'] as $tweet) {
        $autor_id = $tweet['author_id'] ?? null;
        $username = isset($usuarios[$autor_id]['username']) ? $usuarios[$autor_id]['username'] : 'desconocido';

        $fecha=$tweet['created_at'] ?? 'sin_fecha';
        $texto=$tweet['text'] ?? '';
        $respuestas_usuarios=$tweet['public_metrics']['reply_count'] ?? 0;

        //echo "Usuario: @" . $username . PHP_EOL;
        echo "Fecha: " . ($fecha) . PHP_EOL;
        echo "Texto: " . ($texto) . PHP_EOL;

        if (!empty($tweet['public_metrics'])) {
            // echo "Likes: " . ($tweet['public_metrics']['like_count'] ?? 0) . PHP_EOL;
            // echo "Reposts: " . ($tweet['public_metrics']['retweet_count'] ?? 0) . PHP_EOL;
            echo "Respuestas: " . ($respuestas_usuarios) . PHP_EOL;
            // echo "Impresiones: " . ($tweet['public_metrics']['impression_count'] ?? 0) . PHP_EOL;
        }

        echo str_repeat('-', 50) . PHP_EOL;
    }
} else {
    echo "No se encontraron resultados." . PHP_EOL;
}

if (!empty($data['meta']['next_token'])) {
    echo "Siguiente página token: " . $data['meta']['next_token'] . PHP_EOL;
}
?>